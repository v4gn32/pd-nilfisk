import React from 'react';
import { Users, FileText, Upload, TrendingUp, Calendar, Activity, BarChart3, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Document, User } from '../types';
import { mockUsers, mockDocuments } from '../data/mockData';

interface DashboardProps {
  user: User;
  documents: Document[];
}

const Dashboard: React.FC<DashboardProps> = ({ user, documents }) => {
  const isAdmin = user.role === 'ADMIN';
  
  if (isAdmin) {
    // Admin Dashboard
    const totalUsers = mockUsers.length;
    const totalDocuments = mockDocuments.length;
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();
    
    const documentsThisMonth = mockDocuments.filter(doc => 
      doc.month === currentMonth && doc.year === currentYear
    ).length;
    
    const documentsThisYear = mockDocuments.filter(doc => 
      doc.year === currentYear
    ).length;
    
    const documentsByType = {
      HOLERITE: mockDocuments.filter(doc => doc.type === 'HOLERITE').length,
      FERIAS: mockDocuments.filter(doc => doc.type === 'FERIAS').length,
      COMISSAO: mockDocuments.filter(doc => doc.type === 'COMISSAO').length,
      INFORME_RENDIMENTO: mockDocuments.filter(doc => doc.type === 'INFORME_RENDIMENTO').length,
    };
    
    const recentDocuments = mockDocuments
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
    
    const getDocumentTypeLabel = (type: string) => {
      switch (type) {
        case 'HOLERITE': return 'Holerite';
        case 'FERIAS': return 'Férias';
        case 'COMISSAO': return 'Comissão';
        case 'INFORME_RENDIMENTO': return 'Informe de Rendimentos';
        default: return 'Documento';
      }
    };
    
    const getMonthName = (monthNumber: number) => {
      const months = [
        'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
        'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
      ];
      return months[monthNumber - 1] || 'Desconhecido';
    };

    const getUserName = (userId: number) => {
      const user = mockUsers.find(u => u.id === userId);
      return user ? user.name : 'Usuário Desconhecido';
    };

    return (
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-[#28313F]">Painel Administrativo</h1>
          <p className="text-gray-600 mt-1">Visão geral do sistema e estatísticas</p>
        </div>
        
        {/* Cards de Estatísticas Principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-blue-500">
                  <Users className="text-white" size={24} />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-blue-600 font-medium">Total de Usuários</p>
                  <h3 className="text-2xl font-bold text-blue-900">{totalUsers}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-green-500">
                  <FileText className="text-white" size={24} />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-green-600 font-medium">Total de Documentos</p>
                  <h3 className="text-2xl font-bold text-green-900">{totalDocuments}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-purple-500">
                  <Calendar className="text-white" size={24} />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-purple-600 font-medium">Este Mês</p>
                  <h3 className="text-2xl font-bold text-purple-900">{documentsThisMonth}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-orange-500">
                  <TrendingUp className="text-white" size={24} />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-orange-600 font-medium">Este Ano</p>
                  <h3 className="text-2xl font-bold text-orange-900">{documentsThisYear}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Documentos por Tipo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 size={20} />
                Documentos por Tipo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span className="text-blue-700 font-medium">Holerites</span>
                  <span className="text-blue-900 font-bold">{documentsByType.HOLERITE}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="text-green-700 font-medium">Férias</span>
                  <span className="text-green-900 font-bold">{documentsByType.FERIAS}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                  <span className="text-purple-700 font-medium">Comissões</span>
                  <span className="text-purple-900 font-bold">{documentsByType.COMISSAO}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <span className="text-orange-700 font-medium">Informes</span>
                  <span className="text-orange-900 font-bold">{documentsByType.INFORME_RENDIMENTO}</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Atividade Recente */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity size={20} />
                Documentos Recentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {recentDocuments.length > 0 ? (
                <div className="space-y-3">
                  {recentDocuments.map((doc) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-md bg-[#38AFD9]/10">
                          <FileText className="text-[#38AFD9]" size={16} />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{getDocumentTypeLabel(doc.type)}</h4>
                          <p className="text-sm text-gray-600">{getUserName(doc.userId)}</p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="flex items-center text-sm text-gray-500 mb-1">
                          <Calendar size={12} className="mr-1" />
                          <span>{getMonthName(doc.month)} {doc.year}</span>
                        </div>
                        <div className="flex items-center text-xs text-gray-400">
                          <Clock size={10} className="mr-1" />
                          <span>{new Date(doc.createdAt).toLocaleDateString('pt-BR')}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="mx-auto mb-2" size={32} />
                  <p>Nenhum documento encontrado</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Ações Rápidas */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border border-gray-200 rounded-lg hover:border-[#38AFD9] hover:bg-[#38AFD9]/5 transition-all cursor-pointer">
                <div className="flex items-center gap-3">
                  <Upload className="text-[#38AFD9]" size={20} />
                  <div>
                    <h3 className="font-medium">Enviar Documentos</h3>
                    <p className="text-sm text-gray-600">Fazer upload de novos documentos</p>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border border-gray-200 rounded-lg hover:border-[#38AFD9] hover:bg-[#38AFD9]/5 transition-all cursor-pointer">
                <div className="flex items-center gap-3">
                  <Users className="text-[#38AFD9]" size={20} />
                  <div>
                    <h3 className="font-medium">Gerenciar Usuários</h3>
                    <p className="text-sm text-gray-600">Adicionar ou editar usuários</p>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border border-gray-200 rounded-lg hover:border-[#38AFD9] hover:bg-[#38AFD9]/5 transition-all cursor-pointer">
                <div className="flex items-center gap-3">
                  <BarChart3 className="text-[#38AFD9]" size={20} />
                  <div>
                    <h3 className="font-medium">Relatórios</h3>
                    <p className="text-sm text-gray-600">Visualizar estatísticas detalhadas</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // User Dashboard (existing code for regular users)
  const getDocumentCountByType = (type: string) => {
    return documents.filter(doc => doc.type === type).length;
  };
  
  const getLatestDocument = () => {
    if (documents.length === 0) return null;
    
    return documents.reduce((latest, current) => {
      const latestDate = new Date(latest.createdAt);
      const currentDate = new Date(current.createdAt);
      return currentDate > latestDate ? current : latest;
    });
  };
  
  const getCurrentYearDocuments = () => {
    const currentYear = new Date().getFullYear();
    return documents.filter(doc => doc.year === currentYear);
  };
  
  const latestDocument = getLatestDocument();
  const currentYearDocs = getCurrentYearDocuments();
  
  const getDocumentTypeLabel = (type: string) => {
    switch (type) {
      case 'HOLERITE': return 'Holerite';
      case 'FERIAS': return 'Férias';
      case 'COMISSAO': return 'Comissão';
      case 'INFORME_RENDIMENTO': return 'Informe de Rendimentos';
      default: return 'Documento';
    }
  };
  
  const getMonthName = (monthNumber: number) => {
    const months = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    return months[monthNumber - 1] || 'Desconhecido';
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-[#28313F] mb-6">Painel</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {/* Cards de Tipo de Documento */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <FileText className="text-blue-500" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Holerites</p>
                <h3 className="text-2xl font-bold">{getDocumentCountByType('HOLERITE')}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <FileText className="text-green-500" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Férias</p>
                <h3 className="text-2xl font-bold">{getDocumentCountByType('FERIAS')}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <FileText className="text-purple-500" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Comissões</p>
                <h3 className="text-2xl font-bold">{getDocumentCountByType('COMISSAO')}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-orange-100">
                <FileText className="text-orange-500" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Informes</p>
                <h3 className="text-2xl font-bold">{getDocumentCountByType('INFORME_RENDIMENTO')}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Documentos Recentes */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Documentos Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            {documents.length > 0 ? (
              <div className="space-y-4">
                {documents.slice(0, 5).map((doc) => (
                  <div key={doc.id} className="flex items-center p-3 rounded-md hover:bg-gray-50">
                    <div className="p-2 rounded-md bg-gray-100 mr-4">
                      <FileText className="text-blue-500" size={20} />
                    </div>
                    
                    <div>
                      <h4 className="font-medium">{getDocumentTypeLabel(doc.type)}</h4>
                      <div className="flex items-center text-sm text-gray-500">
                        <Calendar size={14} className="mr-1" />
                        <span>{getMonthName(doc.month)} {doc.year}</span>
                      </div>
                    </div>
                    
                    <div className="ml-auto text-xs text-gray-400">
                      {new Date(doc.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>Nenhum documento encontrado</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Card de Resumo */}
        <Card>
          <CardHeader>
            <CardTitle>Resumo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                <span className="text-gray-600">Total de Documentos</span>
                <span className="font-bold">{documents.length}</span>
              </div>
              
              <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                <span className="text-gray-600">Este Ano</span>
                <span className="font-bold">{currentYearDocs.length}</span>
              </div>
              
              {latestDocument && (
                <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                  <span className="text-gray-600">Último Documento</span>
                  <span className="font-bold text-[#38AFD9]">
                    {getDocumentTypeLabel(latestDocument.type)}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;